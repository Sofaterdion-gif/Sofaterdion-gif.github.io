Open Bell 試玩版（Windows 64-bit）
Tirde Studio · https://openbell.me

執行：解壓縮後雙擊 OpenBell.exe。
OpenBell.exe、OpenBell.pck、trading_sim.dll 三個檔案必須放在同一個資料夾。
若 Windows 顯示 SmartScreen 提示，請確認檔案來源是 openbell.me。

這是開發中的試玩版，內容、平衡與介面仍會調整。行情為模擬，不連接真實券商，不構成投資建議。
Copyright © 2026 Tirde Studio · Open Bell™
